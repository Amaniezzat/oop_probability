from setuptools import setup

setup(name='oop_probability',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['oop_probability'],
      author = 'Amani Ezzat',
      author_email = 'amanyezat@gmail.com',
      zip_safe=False)
